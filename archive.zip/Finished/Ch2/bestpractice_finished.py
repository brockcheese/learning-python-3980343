# LinkedIn Learning Python course by Joe Marini
# Example file for Python programming best practices


# 1. Understand the importance of whitespace


# 2. Use descriptive variable and function names


# 3. Write good comments


# 4. Format code to be readable


